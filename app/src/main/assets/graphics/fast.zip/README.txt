Unsolved Case graphics preset: fast
