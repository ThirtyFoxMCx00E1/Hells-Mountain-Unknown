Unsolved Case graphics preset: high
