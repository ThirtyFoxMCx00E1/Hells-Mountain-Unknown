Unsolved Case graphics preset: balanced
